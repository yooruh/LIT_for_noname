import { lib, game, ui, get, ai, _status, X, Y, Z, styleText, B } from '../shared.js';

export const sort = 'ybs';
export const title = `补牌·辅助·${styleText('o', "较难")}`;
export const intro = `如果没人理${B("自高")}，而他又打不出伤害，那很可能被活活拖死。他自带两种模式：牌少回血拿对手牌，牌多扣血送队友牌；对于缺牌的对手和牌多的队友有奇效，`
    + `不过有一定风险。`
    + `<li>主公：回合外的防御牌随便出，压低手牌方便回血。但是回合内的伤害牌不要乱用，尤其是AOE，通过${get.poptip("lit_xinren")}给队友开很关键。不仅可以联动队友的技能，而且队友造成的伤害也能防止回合内的崩血`
    + `<li>忠臣、反贼：主要辅助队友过牌，如果不能保证对手被控，或者让他打不出伤害，就要注意白送${get.poptip("lit_zhanshi")}的风险`
    + "<li>内奸：前期要会忍耐，升级后自己也有输出能力了，再打伤害。有些时候，手牌越少，手牌越多";
export const character = {
    'lit_zigao自高': {
        sex: "male",
        group: "three",
        hp: 4,
        skills: ["lit_shengjizg", "lit_xinren", "lit_chantaer", "lit_zhanshi"],
        isZhugong: true,
    },
};

export const perfectPair = ['lit_zengpinjia曾品嘉', 'lit_lanboxun兰柏勋'];

export const skill = {
    lit_xinren: {
        usable: 1,
        enable: 'phaseUse',
        zhuSkill: true,
        preHidden: true,
        locked: false,
        filter: (event, player) => {
            if (player.countCards('hes') === 0) return false;
            return game.hasPlayer(current => current !== player && (lib.lit.isSameGroup(current, 'three')) && current.isIn());
        },
        filterCard: true,
        position: 'hes',
        discard: false,
        lose: false,
        delay: false,
        check(card) {
            const player = get.owner(card);
            if (get.tag(card, "damage")) return get.value(card);
            if (player.needsToDiscard()) return 11 - get.useful(card);
            return false;
        },
        filterTarget: (card, player, target) => {
            return player !== target && (lib.lit.isSameGroup(target, 'three'));
        },
        async content(event, trigger, player) {
            let cardToUse = event.cards[0],
                user = event.target;
            await player.give(cardToUse, user);
            if (user.hasUseTarget(cardToUse)) {
                user.addTempSkill('lit_xinren_count');
                user.setStorage("lit_xinren_count", [cardToUse, player, 0]);
                await user.chooseToUse(card => card === cardToUse, "【信任】", `是否使用 ${get.translation(cardToUse)}？<li>此牌每造成1点伤害，都会使 ${get.translation(player)} 摸1张牌`)
                    .set("complexSelect", true)
                    .set("filterTarget", function (card, player, target) {
                        return user.canUse(cardToUse, target, true, true);
                    }).set("ai", function (target) {
                        if (!get.tag(cardToUse, "damage")) return get.effect_use(target, cardToUse, player);
                        let att = get.attitude(user, player);
                        return get.effect_use(target, cardToUse, user) + get.sgn(att) * 2;
                    });
            }
        },
        mod: {
            aiValue(player, card, num) {
                if (get.tag(card, "multitarget") && get.tag(card, "damage")) return num + game.players.length;
            },
        },
        ai: {
            order: () => {
                return get.order({ name: "nanman" }) + 0.03;
            },
            threaten: 1.1,
            result: {
                player: 0.6,
                target: (player, target) => {
                    let res = 1 + get.threaten(target) / 2;
                    if (target.countCards("h") <= 2) res += 0.5;
                    return res;
                },
            },
        },
        subSkill: {
            count: {
                silent: true,
                init(player) {
                    player.setStorage("lit_xinren_count", [null, null, 0]);
                },
                trigger: {
                    source: 'damageEnd',
                    player: 'useCardAfter',
                },
                filter: (event, player) => {
                    if (!event.cards[0]) return false;
                    return get.itemtype(event.cards[0]) === "card" && event.cards[0] === player.getStorage("lit_xinren_count", [null, null, 0])[0];
                },
                async content(event, trigger, player) {
                    let state = player.getStorage("lit_xinren_count", [null, null, 0]);
                    if (trigger.name === "damage") {
                        state[2] += trigger.num;
                        player.setStorage("lit_xinren_count", state, true)
                    } else if (player.hasSkill('lit_xinren_count')) {
                        const target = state[1], num = state[2];
                        if (num > 0 && target.isAlive()) {
                            player.line(target, { color: [83, 137, 161] });
                            await target.logSkill('lit_xinren');
                            await target.draw(num).set('source', player);
                        }
                        player.removeSkill('lit_xinren_count');
                    }
                },
                ai: {
                    effect: {
                        player(card, player) {
                            let state = player.getStorage("lit_xinren_count", [null, null, 0]);
                            let cardToUse = state[0],
                                skiller = state[1];
                            let att = get.attitude(player, skiller);
                            if (card === cardToUse && get.tag(cardToUse, "damage")) {
                                return [1, att / 10];
                            }
                        },
                    },
                },
                sub: true,
                sourceSkill: 'lit_xinren',
            },
        },
    },
    lit_zhanshi: {
        utils: {
            evaluate(player, target) {
                const shown = target.countCards('h');
                const giveBack = Math.max(0, player.needsToDiscard(shown, null, true));
                let targetBenefit = giveBack;
                if (target.hasSkill("lit_zhishu")) {
                    const branches = target.getExpansions("lit_zhishu").length;
                    const usefulBranches = Math.max(0, Math.min(giveBack, 6 - branches));
                    const coreBranches = Math.max(0, Math.min(usefulBranches, 3 - branches));
                    targetBenefit = coreBranches * 1.2 + (usefulBranches - coreBranches) * 0.4;
                    if (branches < 3 && branches + giveBack >= 3) targetBenefit += 1.5;

                    const enemies = game.countPlayer(current => current !== target && get.attitude(target, current) < 0 && current.inRange(target));
                    if (shown > 0 && enemies > 0) {
                        const fragile = Math.max(0, 3 - target.hp);
                        targetBenefit -= Math.min(shown, 2) * (0.4 + fragile * 0.6) * Math.min(enemies, 2);
                    }
                }
                return {
                    player: shown - giveBack + get.threaten(target) * (player.hasSkill("lit_zhanshiV2") ? 0.5 : 0),
                    target: -shown + targetBenefit + get.threaten(target) * 0.5,
                };
            },
        },
        usable: 1,
        enable: 'phaseUse',
        locked: false,
        filter: (event, player) => {
            return game.hasPlayer(function (current) {
                return lib.skill.lit_zhanshi.filterTarget(null, player, current);
            });
        },
        filterTarget: (card, player, target) => {
            return player !== target;
        },
        async content(event, trigger, player) {
            let target = event.target;
            if (target.countCards('h') > 0) {
                await target.showCards(target.getCards('h'), `${get.translation(target)} 被 ${get.translation(player)} 点名要求展示`);
                await target.give(target.getCards('h'), player, true);
            }
            let num = player.needsToDiscard();
            if (num) {
                await player.chooseToGive('【展示】', `还给${get.translation(target)} ${num}张牌`, target, num, true)
                    .set("ai", (card, player, target) => {
                        let att = get.attitude(player, target);
                        //if(get.tag(card, "multitarget")&&get.tag(card, "damage"))return -1;
                        return (8 - get.value(card)) * 0.5 + (get.value(card, target) - 6) * get.sgn(att - 0.001);
                    });
            }
            target.addSkill('lit_zhanshi_sub');
        },
        mod: {
            aiOrder(player, card, num) {
                if (player.needsToDiscard(0, null, true) > 0 && get.name(card, player) === "huogong") {
                    return get.order({ name: "wuzhong" }) - 0.1;
                }
            },
        },
        ai: {
            threaten: 1.1,
            order: (item, player) => {
                if (!player) player = get.player();
                if (player.needsToDiscard(0, null, true) > 0) return get.order({ name: "wuzhong" }) - 0.05;
                return get.order({ name: "tiesuo" }) - 0.03;
            },
            result: {
                player: (player, target) => lib.skill.lit_zhanshi.utils.evaluate(player, target).player,
                target: (player, target) => {
                    if (target.hasSkillTag('noh')) return 1;
                    return lib.skill.lit_zhanshi.utils.evaluate(player, target).target;
                },
            },
        },
        subSkill: {
            sub: {
                unique: true,
                silent: true,
                charlotte: true,
                nobracket: true,
                init: (player) => {
                    player.addSkill("lit_zhanshi_math");
                    player.addSkill("lit_zhanshi_mark");
                    let history = player.getAllHistory("useCard");
                    if (history.length) {
                        let trigger = history[history.length - 1],
                            num = get.number(trigger.card);
                        player.setStorage("lit_zhanshi_mark", num);
                        player.markSkill("lit_zhanshi_mark");
                    }
                },
                onremove: (player) => {
                    player.removeSkill("lit_zhanshi_math");
                    player.unmarkSkill("lit_zhanshi_mark");
                    player.removeSkill("lit_zhanshi_mark");
                    player.removeGaintag("lit_zhanshi_math1");
                    player.removeGaintag("lit_zhanshi_math2");
                    delete player.storage.lit_zhanshi_mark;
                },
                trigger: {
                    player: 'phaseAfter',
                },
                async content(event, trigger, player) {
                    player.removeSkill('lit_zhanshi_sub');
                },
                sub: true,
                sourceSkill: 'lit_zhanshi',
            },
            math: {
                getLastUsed: (player, event) => {
                    let history = player.getAllHistory("useCard");
                    let index;
                    if (event) index = history.indexOf(event) - 1;
                    else index = history.length - 1;
                    if (index >= 0) return history[index];
                    return false;
                },
                mod: {
                    cardUsable: function (card, player) {
                        if (typeof card === "object") {
                            let evt = lib.skill.lit_zhanshi_math.getLastUsed(player);
                            if (!evt || !evt.card) return;
                            let num1 = get.number(card),
                                num2 = get.number(evt.card);
                            if (num1 === "unsure" || (typeof num1 === "number" && typeof num2 === "number" && num1 % num2 === 0)) return Infinity;
                        }
                    },
                    aiOrder: function (player, card, num) {
                        if (typeof card === "object") {
                            let evt = lib.skill.lit_zhanshi_math.getLastUsed(player);
                            if (!evt || !evt.card) return;
                            let num1 = get.number(card),
                                num2 = get.number(evt.card);
                            if (num1 === "unsure" || (typeof num1 === "number" && typeof num2 === "number" && num2 % num1 === 0)) return num + 5;
                        }
                    },
                },

                forced: true,
                trigger: { player: "useCard" },
                filter: (event, player) => {
                    let evt = lib.skill.lit_zhanshi_math.getLastUsed(player, event);
                    if (!evt || !evt.card) return false;
                    let num1 = get.number(event.card),
                        num2 = get.number(evt.card);
                    return typeof num1 === "number" && typeof num2 === "number" && num2 % num1 === 0;
                },
                async content(event, trigger, player) {
                    await player.draw();
                },
            },
            mark: {
                mark: true,
                charlotte: true,
                intro: {
                    name: "展示",
                    content: (storage, player) => {
                        return `☝️🤓来欣赏一下数学家！<li>上一张牌的点数：${typeof storage === "number" ? storage : "暂无"}</li>`;
                    },
                    markcount: (storage, player) => {
                        return storage ?? 0;
                    },
                },

                silent: true,
                firstDo: true,
                trigger: {
                    player: ["useCard1", "gainAfter"],
                    global: "loseAsyncAfter",
                },
                filter: function (event, player, name) {
                    return name === "useCard1" || (event.getg(player).length && player.countCards("h"));
                },

                async content(event, trigger, player) {
                    player.removeGaintag("lit_zhanshi_math1");
                    player.removeGaintag("lit_zhanshi_math2");
                    if (event.triggername === "useCard1") {
                        let num = get.number(trigger.card, player);
                        player.setStorage("lit_zhanshi_mark", num);
                        player.markSkill("lit_zhanshi_mark");
                        if (typeof num != "number") return;
                    }
                    let cards1 = [],
                        cards2 = [],
                        num = player.getStorage("lit_zhanshi_mark", undefined);
                    player.getCards("h").forEach(card => {
                        let numx = get.number(card, player);
                        if (typeof numx === "number") {
                            if (numx % num === 0) cards1.push(card);
                            if (num % numx === 0) cards2.push(card);
                        }
                    });
                    player.addGaintag(cards1, "lit_zhanshi_math1");
                    player.addGaintag(cards2, "lit_zhanshi_math2");
                },
            },
        },
    },
    lit_zhanshiV2: {
        inherit: 'lit_zhanshi',
        init: (player) => {
            if (player.hasSkill('lit_zhanshi')) player.removeSkill('lit_zhanshi');
        },
        async content(event, trigger, player) {
            let target = event.target;
            if (target.countCards('h') > 0) {
                await target.showCards(target.getCards('h'), `${get.translation(target)} 被 ${get.translation(player)} 点名要求展示`);
                await target.give(target.getCards('h'), player, true);
            }
            let num = player.needsToDiscard();
            if (num) {
                await player.chooseToGive('【展示】', `还给${get.translation(target)} ${num}张牌`, target, num, true)
                    .set("ai", (card, player, target) => {
                        let att = get.attitude(player, target);
                        //if(get.tag(card, "multitarget")&&get.tag(card, "damage"))return -1;
                        return (8 - get.value(card)) * 0.5 + (get.value(card, target) - 6) * get.sgn(att - 0.001);
                    });
            }
            player.addSkill('lit_zhanshi_sub');
            target.addSkill('lit_zhanshi_sub');
        },
    },
    lit_chantaer: {
        nobracket: true,
        forced: true,
        trigger: {
            player: ['phaseZhunbei', 'phaseJieshu'],
        },
        filter: (event, player, name) => {
            if (name === 'phaseZhunbei') return player.getDamagedHp() > 0 && player.countCards('h') <= player.getHandcardLimit();
            return !game.hasPlayer2(current => {
                return current.getHistory("damage").length > 0;
            }, true);
        },
        async content(event, trigger, player) {
            if (event.triggername === 'phaseZhunbei') {
                player.say("要是本回合无人受伤，我铲踏儿！");
                await player.recover();
            } else {
                await player.draw(2);
                await player.loseHp();
            }
        },
        mod: {
            maxHandcardBase: (player, num) => {
                return player.maxHp;
            },
            aiUseful(player, card, num) {
                if (['sha', 'shan', 'wuxie', 'tao'].includes(get.name(card, player))) {
                    return Math.min(num * 1.2, 10);
                }
            },
        },
        ai: {
            order: 6.4,
            threaten: 0.7,
            effect: {
                target(card, player, target) {
                    if (get.tag(card, "skip") === "phaseUse") return [1, -1];
                },
                player_use(card, player, target) {
                    if (get.tag(card, "damage")) {
                        if (player.hp === 1 && !player.canSave(player)) return [1, 3];
                        if (player.hp < 3) return [1, 1];
                    }
                },
            },
        },
    },
};

export const translate = {
    'lit_zigao自高': "自高",
    'lit_xinren': "信任",
    'lit_xinren_info': "主公技，出牌阶段限一次，你可以交给一名“叁”势力角色一张牌，其可立即使用之，然后你摸X张牌（X为此牌造成的伤害值）",
    'lit_zhanshi': "展示",
    'lit_zhanshi_info': `出牌阶段限一次，你可以令一名其他角色展示所有手牌并交给你，然后你交给其${X}张牌，直到其回合结束，其使用点数为${Y}的牌：<li>倍数，无次数限制；</li><li>约数，其摸一张牌</li>（${X}为你的手牌溢出量，${Y}为其使用的上一张牌的点数）`,
    'lit_zhanshiV2': "展示",
    'lit_zhanshiV2_info': `出牌阶段限一次，你可以令一名其他角色展示所有手牌并交给你，然后你交给其${X}张牌，直到你或其回合结束，你或其使用点数为${Y}的牌：<li>倍数，无次数限制；</li><li>约数，摸一张牌</li>（${X}为你的手牌溢出量，${Y}为其使用的上一张牌的点数）`,
    'lit_zhanshi_sub': `<span class='bluetext'>【展示】</span>`,
    'lit_zhanshi_math1': "倍数",
    'lit_zhanshi_math2': "约数",
    'lit_zhanshi_sub_info': `<span class='bluetext'>直到下回合结束，使用点数为${Y}的牌：<li>倍数，无次数限制；</li><li>约数，摸一张牌</li>（${Y}为使用的上一张牌的点数）</span>`,
    'lit_chantaer': "铲踏儿",
    'lit_chantaer_info': "锁定技，你的手牌上限基数为你的体力上限；准备阶段，若你的手牌数不大于手牌上限，你恢复1点体力；结束阶段，若本回合没有角色受到过伤害，你摸两张牌并失去1点体力",
    'lit_shengjizg': "升级·自高",
    'lit_shengjizg_info': `${get.poptip('lit_zhanshiV2')} 获得并修改〖展示〗：你也拥有后半段技能效果`,
};

export const simpleTranslate = {
    'lit_xinren_info': "主；出牌限1次，交给某“叁”势力角色1牌，其可立即使用，你摸与该牌造成的总伤害相等的牌",
    'lit_zhanshi_info': `出牌限1次，令他人展示所有手牌并给你，你给其${X}牌，直到其下回合结束，其使用牌点数为${Y}的：<li>倍数，无次数限制；</li><li>约数，+1牌</li>（${X}为手牌溢出量，${Y}为其使用的上一牌的点数）`,
    'lit_zhanshiV2_info': `V2 出牌限1次，令他人展示所有手牌并给你，你给其${X}牌，直到你/其下回合结束，你/其使用牌点数为${Y}的：<li>倍数，无次数限制；</li><li>约数，+1牌</li>（${X}为手牌溢出量，${Y}为使用的上一牌的点数）`,
    'lit_chantaer_info': "锁；手牌上限基准为体力上限<li>准备阶段手牌数≤上限+1血</li><li>结束阶段本回合无人受过伤摸2牌并-1血</li>",
    'lit_shengjizg_info': `${get.poptip('lit_zhanshiV2')} 获得并修改“展示”：你也拥有后半段技能`,
};

export const dynamicTranslate = {
    lit_xinren(player) {
        let group = lib.lit.isGuozhanKeyEnabled() ? '叁/键' : '叁';
        return `主；出牌限1次，交给某“${group}”势力角色1牌，其可立即使用，你摸与该牌造成的总伤害相等的牌"`;
    },
};
