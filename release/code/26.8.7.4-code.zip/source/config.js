import { lib, game, ui, get, ai, _status } from '../../../noname.js';
import { dialogManager } from './tool/ui/dialogManager.js'
import { extensionUpdateManager } from './tool/update/index.js';
import { configManager } from './tool/configuration/configManager.js'
import { extensionPath } from './tool/utils/paths.js'
import { themeManager } from './tool/ui/themeManager.js'

// 本体菜单更新，未来可期
// update(config, map) {
// 	if (config.fix_onlineFixCancel === true) {
// 		map.lit_fg0.hide();
// 		map.main_audio.hide();
// 		map.main_cdown.hide();
// 		map.edit_emojiAllowed.hide();
// 		map.play_observeChat.hide();
// 		map.edit_alone.hide();
// 		map.play_mima.hide();
// 		map.setMima.hide();
// 		map.play_tipPlayerVersion.hide();
// 		map.play_tipNonamePlayer.hide();
// 		map.play_tipExtension.hide();
// 		map.fun_handCardsFix.hide();
// 		map.fun_beginDraw.hide();
// 		map.fun_replaceHandCards.hide();
// 		map.edit_cardsInfo.hide();
// 	} else {
// 		map.lit_fg0.show();
// 		map.main_audio.show();
// 		map.main_cdown.show();
// 		map.edit_emojiAllowed.show();
// 		map.play_observeChat.show();
// 		map.edit_alone.show();
// 		map.play_mima.show();
// 		map.setMima.show();
// 		map.play_tipPlayerVersion.show();
// 		map.play_tipNonamePlayer.show();
// 		map.play_tipExtension.show();
// 		map.fun_handCardsFix.show();
// 		if (config.fun_handCardsFix === true) {
// 			map.fun_beginDraw.show();
// 			map.fun_replaceHandCards.show();
// 		} else {
// 			map.fun_beginDraw.hide();
// 			map.fun_replaceHandCards.hide();
// 		}
// 		map.edit_cardsInfo.show();
// 	}
// }

export const config = {
	lit_help: {
		name: '<button class="lit-config-button">帮助文档</button>',
		intro: "查看叁岛世界相关设置的完整帮助页面",
		clear: true,
		async onclick() {
			try {
				await dialogManager.showDocModal(
					`${extensionPath}/style/html/help.html`,
					'帮助文档'
				);
			} catch (error) {
				console.error("获取【叁岛世界】帮助文档失败", error);
				alert("获取【叁岛世界】帮助文档失败");
			}
		}
	},
	lit_updateOnline: {
		name: '<button class="lit-config-button">在线更新扩展</button>',
		intro: "从GitHub/Gitee在线获取扩展并更新",
		clear: true,
		async onclick() {
			await extensionUpdateManager.showUI();
		}
	},
	lit_recommendConfig: {
		name: '<button class="lit-config-button">应用推荐的无名杀全局设置</button>',
		intro: "载入相对适配《叁岛世界》的“无名杀全局设置”，同时可备份当前配置到files目录",
		clear: true,
		async onclick() {
			await configManager.showUI();
		}
	},
	lit_uiTheme: {
		name: '扩展界面主题',
		intro: '选择叁岛世界自身界面的配色；“跟随系统”会按设备浅色/深色偏好自动切换。',
		init: 'system',
		item: {
			system: '跟随系统',
			light: '浅色',
			dark: '深色',
		},
		onclick: (theme) => {
			themeManager.save(theme);
		},
	},
	lit_uiOpacity: {
		name: 'UI不透明度',
		intro: '调整叁岛世界界面（对话框、按钮）背景的不透明度；文字保持不透明。',
		init: '100',
		item: {
			'100': '不透明 100%',
			'90': '90%',
			'75': '75%',
			'60': '60%',
			'50': '50%',
			'25': '25%',
		},
		onclick: (opacity) => {
			themeManager.saveOpacity(opacity);
		},
	},
	lit_dkwsl: {
		name: "吊卡无势力限制",
		init: false,
		intro: "开启后，允许非“九”“叁”势力角色直接使用吊卡",
		onclick: (item) => {
			game.saveExtensionConfig('叁岛世界', 'lit_dkwsl', item);
		}
	},
	lit_sdhhBanned: {
		name: "禁用叁岛幻化",
		init: false,
		intro: "开启后，不再启用独立的叁岛幻化模式，但乱斗模式中的叁岛幻化不受影响",
		onclick: (item) => {
			game.saveExtensionConfig('叁岛世界', 'lit_sdhhBanned', item);
		}
	},
	lit_guozhanAllowed: {
		name: "叁岛国战（实验）",
		init: false,
		intro: "开启后，将叁岛世界角色改为“键”势力并加入到国战模式中，重启生效",
		onclick: (item) => {
			game.saveExtensionConfig('叁岛世界', 'lit_guozhanAllowed', item);
			if (!item) return;
			lib.config.characters.add('lit_gz');
			game.saveConfig("characters", lib.config.characters);
		}
	},
	fix_onlineFixCancel: {
		name: "关闭联机修改功能",
		init: false,
		intro: "取消导入联机修改基础函数集，重启生效",
		onclick: (item) => {
			game.saveConfig('extension_叁岛世界_fix_onlineFixCancel', item)
			// if (item) {
			// 	Object.keys(map).forEach(s => {
			// 		if(!s.startsWith('lit_') && s != "intro"){
			// 			map[s].hide();
			// 		}
			// 	});
			// } else {
			// 	Object.keys(map).forEach(s => {
			// 		if(!s.startsWith('lit_') && s != "intro"){
			// 			map[s].show();
			// 		}
			// 	});
			// 	if (!config.fun_handCardsFix){
			//		fun_beginDraw.hide();
			// 		map.fun_replaceHandCards.hide();
			// 	}
			// }
		}
	},
	lit_fg0: {
		name: "<span class='lit-config-section'>—— 联机修改 ——</span>",
		clear: true,
		nopointer: true,
	},
	main_audio: {
		name: '指令播放角色音频',
		intro: '在聊天框可使用/s /d 播放技能音效或阵亡音效，详见帮助按钮',
		init: true,
	},
	main_cdown: {
		name: '聊天发送弹幕',
		intro: '每个玩家发送消息后，都会变成弹幕',
		init: true,
	},
	edit_emojiAllowed: {
		name: '允许发布表情、颜文字',
		intro: '（限私服）发送内容中的表情、颜文字等不再仅自己可见，若遇Bug请关闭',
		init: false,
	},
	play_observeChat: {
		name: '允许旁观发言',
		intro: '即使是旁观的玩家，也能够正常发言',
		init: true,
	},
	edit_alone: {
		name: '允许单人开房',
		intro: '（限私服）删除至少要有两名玩家才能开始游戏的限制，直接打人机',
		init: false,
	},
	play_mima: {
		name: '进入房间需输入密码',
		intro: '开启并重启后，在下方会出现一个输入密码的按钮，加入你的房间时必须输入此密码才可加入，再次重启后生效',
		init: false,
		onclick(bool) {
			game.saveConfig('extension_叁岛世界_play_mima', bool);
			// suiSet.setMima()
		}
	},
	get setMima() {
		if (lib.config['extension_叁岛世界_play_mima']) {
			return {
				name: '<button class="lit-config-button">设置密码</button>',
				intro: "",
				clear: true,
				async onclick() {
					const password = await dialogManager.input(
						'设置房间密码',
						`当前密码：${lib.config['叁岛世界mima'] || '无'}\n\n留空并确认不会修改当前密码。`,
						'',
						{ password: true, placeholder: '输入新密码', confirmText: '下一步' }
					);
					if (password === null) return;
					if (password) game.saveConfig('叁岛世界mima', password);

					const tip = await dialogManager.input(
						'设置密码错误提示',
						`当前提示：${lib.config['叁岛世界_tip'] || '无'}\n\n留空并确认不会修改当前提示。`,
						'',
						{ rows: 2, placeholder: '输入提示文字' }
					);
					if (tip) game.saveConfig('叁岛世界_tip', tip);
				}
			}
		}
		return {
			name: '',
			clear: true,
		}
	},
	play_tipPlayerVersion: {
		name: '检查版本与房主一致',
		intro: '无名杀版本与房主不同的玩家进入房间时，会弹窗提醒他',
		init: true,
	},
	play_tipNonamePlayer: {
		name: '提醒无名玩家改名',
		intro: '名称为“无名玩家”的玩家进入房间时，会弹窗提醒他改名',
		init: true,
	},
	play_tipExtension: {
		name: '扩展缺失提醒',
		intro: '缺失可能的必要扩展，或相关扩展未启用的玩家进入房间时，会弹窗提醒他缺失的扩展列表',
		init: false,
	},
	fun_handCardsFix: {
		name: '修改起始发牌和手气卡',
		intro: '开启后，下面两个设置才会生效，重启生效',
		init: false,
	},
	fun_beginDraw: {
		name: '起始发牌',
		frequent: true,
		init: '4',
		item: Array.from({ length: 100 }, (_, i) => String(i)),
	},
	fun_replaceHandCards: {
		name: '手气卡次数',
		frequent: true,
		init: "0",
		item: Array.from({ length: 100 }, (_, i) => String(i)),
	},
	edit_cardsInfo: {
		name: '卡牌上显示出牌信息',
		intro: '在打出的卡牌下方显示一行小字：“xx对xx使用”“xx打出”等',
		init: true,
	},
	intro: {
		name: "作者：一个月惹",
		clear: true,
		nopointer: true,
		onclick: () => {
			let count = game.getExtensionConfig('叁岛世界', 'intro_count') ?? 0;
			game.saveExtensionConfig('叁岛世界', 'intro_count', (++count) % 3);
			if (count == 3) debugger;
		}
	},
}

export const mainConfig = [];
export const playerConfig = [];
export const editConfig = [];
Object.keys(config).forEach(item => {
	if (item.startsWith('play_')) playerConfig.push(item);
	if (item.startsWith('main_')) mainConfig.push(item);
	if (item.startsWith('edit_')) editConfig.push(item);
});